# strona_projekt_finanse

## General info

### Features
- 
## Technologies

The project uses many technologies such as:

- [HTML] - HTML enhanced for web apps!
- [CSS] - Markdown parser done right. Fast and easy to extend.
- [JS] - awesome web-based text editor
- [PHP] - Markdown parser done right. Fast and easy to extend.
- [SQL] - Markdown parser done right. Fast and easy to extend.

## License

   [HTML]: <https://en.wikipedia.org/wiki/HTML>
   [JS]: <https://en.wikipedia.org/wiki/JavaScript>
   [CSS]: <https://en.wikipedia.org/wiki/CSS>
   [PHP]: <https://www.php.net>
   [SQL]: <https://en.wikipedia.org/wiki/SQL>
   