<?php
    $host="localhost";
    $db_user="root";
    $db_password="";
    $db_name="wydatki_v.3.0";
?>